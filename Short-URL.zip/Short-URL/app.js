const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.set("view engine", "ejs");
app.set("views", "./views");
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const urlsFilePath = path.join(__dirname, "urls.json");

fs.writeFileSync(urlsFilePath, "{}");

function readUrlsFromFile() {
  try {
    if (fs.existsSync(urlsFilePath)) {
      const data = fs.readFileSync(urlsFilePath, "utf8");
      return JSON.parse(data);
    }
    return {};
  } catch (error) {
    console.error("Error reading URLs file:", error);
    return {};
  }
}

function writeUrlsToFile(urls) {
  try {
    fs.writeFileSync(urlsFilePath, JSON.stringify(urls, null, 2));
  } catch (error) {
    console.error("Error writing URLs file:", error);
  }
}

function generateShortId(length = 6) {
  const characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

app.get("/", (req, res) => {
  const urls = readUrlsFromFile();
  res.render("index", { urls, error: null, success: null });
});

app.post("/shorten", (req, res) => {
  const { longUrl } = req.body;

  if (!longUrl) {
    const urls = readUrlsFromFile();
    return res.render("index", {
      urls,
      error: "Please enter a valid URL",
      success: null,
    });
  }

  const validUrl =
    longUrl.startsWith("http://") || longUrl.startsWith("https://")
      ? longUrl
      : "https://" + longUrl;

  const urls = readUrlsFromFile();

  let shortId;
  do {
    shortId = generateShortId();
  } while (urls[shortId]);

  urls[shortId] = {
    longUrl: validUrl,
    createdAt: new Date().toISOString(),
    clicks: 0,
  };

  writeUrlsToFile(urls);

  res.render("index", {
    urls,
    error: null,
    success: `Short URL created: ${req.get("host")}/${shortId}`,
  });
});

app.get("/:shortId", (req, res) => {
  const { shortId } = req.params;
  const urls = readUrlsFromFile();

  if (urls[shortId]) {
    urls[shortId].clicks++;
    writeUrlsToFile(urls);

    return res.redirect(urls[shortId].longUrl);
  } else {
    res.status(404).render("index", {
      urls,
      error: `Short URL "${shortId}" not found`,
      success: null,
    });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
